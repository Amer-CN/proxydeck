synthetic fixture for the P8c gate
